import { useEffect, useState } from "react";
import UsersList from "./components/UsersList";
import User from "./components/User";
import "./App.css";

function App() {
  const [users, setUsers] = useState([]);
  useEffect(() => {
    fetch("https://api.github.com/users")
      .then((responce) => responce.json())
      .then((json) => setUsers(json));
  }, []);
    
  const deleteButton = ()=>{
  alert("delete");
}
  return <div>
    <input/>
    <UsersList users = {users}/>
    <User deleteButton={deleteButton} />
  </div>;
}

export default App;



export default function User({id,login,avatar_url,deleteButton}){
    return <div className="user-container">
        <div className="ButtonXDiv">
        <button className="ButtonX" onClick={deleteButton}>X</button>
        </div>
        <img src={avatar_url} alt="image" className="img"/>
        <div className="login-Id">
        <p>{login}</p>
        <div className="ID">
        <span>ID: {id}</span>
        </div>
        </div>
    </div>
}